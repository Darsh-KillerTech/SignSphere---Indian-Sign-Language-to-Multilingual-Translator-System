# YOLO Object Detection Web App

## 🚀 Overview
This is a web-based object detection app using the **YOLO** model. It captures real-time video from a webcam, detects objects, and displays the results in a web interface.

## 📁 Project Structure
```
yolo_webapp/
│
├── app.py                 # Flask backend
├── requirements.txt        # Dependencies list
├── best.pt                # Trained YOLO model
│
├── templates/             # Frontend templates
│   └── index.html         # Main UI
│
└── static/                # Static assets (CSS, JS)
    ├── css/
    │   └── styles.css     # Styling
    └── js/
        └── app.js         # JavaScript (optional)
```

## 🛠️ Installation
### **1️⃣ Clone Repository**
```bash
git clone https://github.com/your-username/yolo-webapp.git
cd yolo-webapp
```

### **2️⃣ Install Dependencies**
```bash
pip install -r requirements.txt
```

### **3️⃣ Run the App**
```bash
python app.py
```
Then, open your browser and go to:
```
http://127.0.0.1:5000
```

## 🌍 Deployment on Render
1. Push your project to GitHub.
2. Go to [Render](https://render.com/) and create a **new web service**.
3. Connect your **GitHub repository**.
4. Set up the deployment:
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `gunicorn app:app`
   - **Port:** `10000`
5. Deploy and get your **public URL**.

## 🏆 Features
✅ Real-time object detection with **YOLO**
✅ Web-based interface using **Flask**
✅ Responsive design
✅ Easy deployment to **Render**

## 📌 Next Steps
🔹 Optimize performance for faster detections
🔹 Add an option to upload videos for analysis
🔹 Deploy on **Google Cloud / AWS** for better scalability

## 💡 Contributing
Feel free to fork this repo and submit pull requests!

## 📜 License
MIT License

