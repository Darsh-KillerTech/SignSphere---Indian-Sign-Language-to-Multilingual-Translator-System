// Example: Add additional interactivity if needed
document.getElementById('videoStream').onclick = () => {
    alert('Video Stream Clicked!');
};
