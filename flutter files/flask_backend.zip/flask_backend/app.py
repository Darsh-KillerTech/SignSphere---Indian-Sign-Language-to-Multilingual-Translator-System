from flask import Flask, request, jsonify
import cv2
import numpy as np
from ultralytics import YOLO
import base64

app = Flask(__name__)

# Load YOLO model
model = YOLO("best.pt")  # Ensure the 'best.pt' file is in the same directory
names = model.names

@app.route('/')
def home():
    return "YOLO Object Detection API is running! Use POST /detect to send images."

@app.route('/detect', methods=['POST'])
def detect():
    try:
        if 'image' not in request.json:
            return jsonify({"error": "Missing image data"}), 400
        
        # Decode base64 image
        data = request.json['image']
        image_bytes = base64.b64decode(data)
        nparr = np.frombuffer(image_bytes, np.uint8)
        frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

        if frame is None:
            return jsonify({"error": "Invalid image format"}), 400

        # Resize image before processing
        frame = cv2.resize(frame, (640, 640))
        
        # Run YOLO detection
        results = model.track(frame, persist=True)
        detections = []
        translated_text = ""

        if results[0].boxes is not None and results[0].boxes.id is not None:
            boxes = results[0].boxes.xyxy.int().cpu().tolist()
            class_ids = results[0].boxes.cls.int().cpu().tolist()
            confidences = results[0].boxes.conf.cpu().tolist()

            for box, class_id, conf in zip(boxes, class_ids, confidences):
                x1, y1, x2, y2 = box
                label = f"{names[class_id]} {conf:.2f}"
                translated_word = names[class_id]  # Direct mapping for now
                translated_text += translated_word + " "
                
                # Draw bounding box
                cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                cv2.putText(frame, label, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
                
                detections.append({
                    "label": names[class_id],
                    "translated": translated_word,
                    "confidence": float(conf),
                    "box": box
                })
        
        return jsonify({"detections": detections, "translated_text": translated_text.strip()})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=False, host='0.0.0.0', port=10000)
